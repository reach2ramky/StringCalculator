import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class StringCalculatorTest {

	@Test
	public void shouldReturnZeroIfInputEmpty() {
		assertEquals(0, StringCalclator.addNumbers(""));
	}

	@Test
	public void shouldReturnZeroIfInputNull() {
		assertEquals(0, StringCalclator.addNumbers(null));
	}

	@Test
	public void shouldReturnNumberOnSingleNumber() {
		assertEquals(25, StringCalclator.addNumbers("25"));
	}

	@Test
	public void shouldAcceptValidDelimiter() {
		assertEquals(10, StringCalclator.addNumbers("3,3,4"));
	}

	@Test
	public void shouldAcceptOtherValidDelimiter() {
		assertEquals(10, StringCalclator.addNumbers("3..3..4"));
	}
	
	@Test
	public void shouldAcceptSplCharDelimiter() {
		assertEquals(10, StringCalclator.addNumbers("3@3@4"));
	}
	
	@Test
	public void shouldAcceptAlphabateAsDelimiter() {
		assertEquals(10, StringCalclator.addNumbers("3ab3ab4"));
	}

	@Test
	public void shouldReturnSumofTwoNumbers() {
		assertEquals(6, StringCalclator.addNumbers("3,3"));
	}

	@Test
	public void shouldReturnSumofMultipleNumbers() {
		assertEquals(10, StringCalclator.addNumbers("3,3,4"));
	}

	@Test
	public void raiseExceptionOnNegativeValue() {
		try {
			StringCalclator.addNumbers("3,-3,2");
			fail("Negative Value not allowed Exception");
		} catch (RuntimeException re) {
			//
		}
	}

	@Test
	public void ignoreMaxNumber() {
		assertEquals(7, StringCalclator.addNumbers("101,3,4"));
	}
}
