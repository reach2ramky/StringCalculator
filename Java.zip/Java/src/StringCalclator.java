
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class StringCalclator {
	
	final static String regex = "[, // . ' \\\\n \\\\| * $ # % & @ : ; ' ! \\[  \\] \\{ \\} ]|[a-zA-Z]";

	/*
	 * 1. adds numbers present in the input, e.g "1,2" = 3 2. treats empty or null
	 * input as zero, e.g "" = 0, null = 0 3. supports different delimiters, e.g
	 * "1,2,3", "1 2 3" 4. does not support negative numbers 5. ignores numbers
	 * greater than 100
	 */

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Get String input from the user
		Scanner sc = new Scanner(System.in);

		try {
			String input = sc.next();
			int output = addNumbers(input);

			System.out.println(output);

		} catch (NumberFormatException ne) {
			throw new NumberFormatException(ne.getMessage());
		} catch (Exception ex) {
			throw new RuntimeException(ex.getMessage());
		}
		
		finally {
			sc.close();
		}

	}

	public static int addNumbers(String inputString) throws NumberFormatException {

		List<Integer> numberList;
		int total = 0;
		
		try {

			if (inputString != null && !inputString.isEmpty()) {

				//replace any delimiter with custom delimiter
				inputString = replaceStringWithCustomDelimiter(inputString);
				//Split string and store in String Array
				String[] strInput = splitStringWithDelimiter(inputString);

				
				numberList = new ArrayList<Integer>();
				//convert StringArray to IntegerList
				numberList = convertToIntList(strInput); 
				//check if any number has negative value
				numberList = negativeValueCheck(numberList);
				//check if any value is >100
				numberList = maxNumbercheck(numberList);

				//sum the numbers in IntegerList
				total = sum(numberList);

			} else {
				System.out.println("Input is either Empty or null.");
				return 0;

			}

		} finally {
			numberList = null;
		}
		return total;
	}

	//Replace inputString delimiter
	private static String replaceStringWithCustomDelimiter(String inputString) {
		// TODO Auto-generated method stub
		inputString = inputString.replaceAll(regex, " ");
		return inputString;
	}

	//Check if any number is above limit
	private static List<Integer> maxNumbercheck(List<Integer> intArrayInput) {
		// TODO Auto-generated method stub

		Iterator<Integer> it = intArrayInput.iterator();

		while (it.hasNext()) {
			if (it.next() > 100) {
				it.remove();
			}
		}

		return intArrayInput;
	}

	// Check the negative value in the provided list, if found - throw Runtime
	// Exception
	private static List<Integer> negativeValueCheck(List<Integer> intArrayInput) {
		// TODO Auto-generated method stub

		Iterator<Integer> it = intArrayInput.iterator();
		while (it.hasNext()) {
			if (it.next() < 0) {
				throw new RuntimeException();
			}
		}

		return intArrayInput;
	}

	//Addition of numbers and return output
	private static int sum(List<Integer> numberList) {
		int output = 0;

		for (int j : numberList) {
			output = output + j;
		}

		return output;
	}

	//Split string with custom delimiter and store in StringArray
	private static String[] splitStringWithDelimiter(String s) {

		String[] strInput = s.split("\\s");

		for (int i = 0; i < strInput.length; i++) {
			if (strInput[i].isEmpty()) {
				strInput[i] = "0";
			}
		}

		return strInput;

	}

	private static List<Integer> convertToIntList(String[] strArray) throws NumberFormatException {

		List<Integer> numberList = new ArrayList<Integer>();

		for (int i = 0; i < strArray.length; i++) {

			// Iterate through stringArray and add it to the IntegerList
			numberList.add(Integer.parseInt(strArray[i]));

		}

		return numberList;
	}

}
